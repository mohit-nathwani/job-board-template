# Job Board Template

Base Next.js 14 template for niche job boards.
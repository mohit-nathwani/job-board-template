export default function Home() {
  return (
    <main className="min-h-screen grid place-items-center">
      <div className="p-10 bg-white border rounded-xl shadow text-3xl font-semibold">
        Hello World – Job Board Template 🏗️
      </div>
    </main>
  );
}